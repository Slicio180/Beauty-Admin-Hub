# Pool board gaps — development checkpoint, 6 November 2026

This is unfinished work, saved so the verified editing change is not lost. It is not a completed native assignment update and has no installer. Existing Mac, Google TEST and production were not changed. The separate Event Manager project was not changed.

## Gap 1: running board editing — local PASS

Pool cards retain board selectors and Save during play. Each running save requires the loaded event/board-plan revision; stale tabs and changed group membership are rejected. Audit includes the previous and next plan. No Nakka write, score change, group replacement or repeated Start. This remains a Hub venue plan until gap 2 is implemented.

Source is based on the installed tournament-control baseline, without installing the separately deferred plain-label rename update. Target remains Identity TEST only.

766 baseline tests passed; 770 updated tests passed. Inventory: 770 cases, 57 files, PASS. Full reports and source before/after are included.

## Gap 2: actual Nakka routing — blocked, not fixed

The public API documents badge/update for rr, but does not fully specify the pool match/address correspondence. The cached native participant script shows rr_board also represents simultaneous-game/shared-pool behaviour; it is not a list of physical board numbers. No guessed rr_board array or guessed badge index was written. Native admin resources and public API readback were inaccessible in this environment; no authenticated native session/credentials are available.

To resume: inspect one native RR board-management example and capture the resulting tournament fields. The new private owner-editor function beautyPoolBoardReadback_ only reads the existing fixed TEST target and returns rr_table/rr_seq/rr_order/rr_board/rr_disable/rr_memo/badge, status and revision. It excludes entry names, scores, passwords and admin IDs. It is not a public RPC and performs no write. Its local synthetic test is not native qualification.

Preserve completed TEST t_QHaG_7792. Do not change its results, restart it, resend its pools or reassign its knockouts. Any actual assignment qualification must use a separate TEST event. Validate pair identity, paused/active/finished games, queued reuse, two simultaneous boards, stale saves, uncertain writes and readback before enabling the native writer. Do not mark every future match as in progress at once.

Official reference checked: https://push.n01darts.com/api/v1/n01_api_manual_en.html

No Google upload, Nakka mutation, production change or GitHub push occurred.
