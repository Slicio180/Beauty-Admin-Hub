const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const pkg=__dirname,api=require(pkg+'/upload-test.cjs');
function fixture(mode){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'beauty-upload-check-')),root=path.join(dir,'root'),bundle=path.join(dir,'bundle');fs.mkdirSync(root+'/backups',{recursive:true});fs.mkdirSync(bundle);for(const f of ['manifest.json','google-files.json'])fs.copyFileSync(pkg+'/'+f,bundle+'/'+f);
 const mapping=JSON.parse(fs.readFileSync(pkg+'/google-files.json')),remote={'appsscript.json':'{"timeZone":"Europe/Berlin","runtimeVersion":"V8"}','Code.js':'function untouched(){return "keep";}','HubTestAuth.js':'function auth(){return "preserved";}'};
 for(const [source,target]of mapping){const rel='apps-script/registration-identity-test/remote-app/'+source,p=root+'/'+rel;fs.mkdirSync(path.dirname(p),{recursive:true});fs.copyFileSync(pkg+'/payload/'+rel,p);remote[target.replace(/\.gs$/,'.js')]=fs.readFileSync(pkg+'/before/'+rel,'utf8');}
 let pushes=0,clones=0;
 const run=(args,cwd)=>{
  if(args[0]==='clone-script'){
   clones++;assert.equal(args[1],api.SCRIPT);if(mode==='race'&&clones===2)remote['Code.js']='changed meanwhile';
   fs.writeFileSync(cwd+'/.clasp.json',JSON.stringify({scriptId:mode==='wrong'? 'WRONG':api.SCRIPT}));
   for(const [n,v]of Object.entries(remote))fs.writeFileSync(cwd+'/'+n,mode==='readback'&&clones===3&&n==='HubTest.html'?'mismatch':v);
  }else {assert.deepEqual(args,['push','--force']);pushes++;assert.equal(JSON.parse(fs.readFileSync(cwd+'/.clasp.json')).scriptId,api.SCRIPT);for(const n of Object.keys(remote))remote[n]=fs.readFileSync(cwd+'/'+n,'utf8');if(mode==='uncertain')throw Error('timeout');}
 };
 return {root,bundle,remote,run,pushes:()=>pushes,cleanup:()=>fs.rmSync(dir,{recursive:true,force:true})};
}
test('one TEST replacement preserve other files and complete full readback; repeat does not push',()=>{const f=fixture();try{const r=api.main(f.root,f.bundle,f.run);assert.equal(r.changedFiles,1);assert.equal(r.filesVerified,4);assert.equal(f.remote['Code.js'],'function untouched(){return "keep";}');assert.equal(f.remote['HubTestAuth.js'],'function auth(){return "preserved";}');assert.equal(api.main(f.root,f.bundle,f.run).changedFiles,0);assert.equal(f.pushes(),1);}finally{f.cleanup();}});
test('wrong project and unknown Google baseline refuse all uploads',()=>{for(const mode of ['wrong','unknown']){const f=fixture(mode);try{if(mode==='unknown')f.remote['HubTest.html']='unreviewed edit';assert.throws(()=>api.main(f.root,f.bundle,f.run));assert.equal(f.pushes(),0);}finally{f.cleanup();}}});
test('concurrent Google edit is detected before push',()=>{const f=fixture('race');try{assert.throws(()=>api.main(f.root,f.bundle,f.run),/changed during/);assert.equal(f.pushes(),0);}finally{f.cleanup();}});
test('failed readback leaves an uncertain marker and does not retry',()=>{const f=fixture('readback');try{assert.throws(()=>api.main(f.root,f.bundle,f.run),/readback differs/);assert.equal(f.pushes(),1);assert.equal(JSON.parse(fs.readFileSync(f.bundle+'/google-upload-state.json')).state,'ATTEMPTED');}finally{f.cleanup();}});
test('upload timeout is not retried; successful later readback reconciles without another push',()=>{const f=fixture('uncertain');try{assert.throws(()=>api.main(f.root,f.bundle,f.run),/timeout/);assert.equal(f.pushes(),1);assert.equal(api.main(f.root,f.bundle,f.run).state,'VERIFIED');assert.equal(f.pushes(),1);}finally{f.cleanup();}});
