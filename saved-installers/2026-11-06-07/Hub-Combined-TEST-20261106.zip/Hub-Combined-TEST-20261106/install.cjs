'use strict';
/* Local TEST source installer. No network, Google, Nakka, Git or deployment commands. */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process'),os=require('node:os');
const bundle=__dirname,root=path.resolve(process.argv[2]||process.cwd());
const manifest=JSON.parse(fs.readFileSync(path.join(bundle,'manifest.json'),'utf8'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const normalized=b=>hash(Buffer.from(b.toString('utf8').replace(/\r\n/g,'\n').replace(/\n+$/,'')));
function safe(rel){
 if(path.isAbsolute(rel)||rel.split('/').includes('..'))throw Error('Invalid package path.');
 const dest=path.join(root,rel);let current=root;
 for(const bit of rel.split('/')){current=path.join(current,bit);if(fs.existsSync(current)&&fs.lstatSync(current).isSymbolicLink())throw Error('Refusing symbolic link: '+rel);}
 return dest;
}
function discover(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>{const p=path.join(dir,e.name);return e.isDirectory()?discover(p):e.name.endsWith('.test.cjs')?[p]:[];});}
function isolatedCopy(work) {
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'beauty-ui-check-'));
 const copy=path.join(temp,'Beauty-Admin-Hub');
 try {
  fs.cpSync(root,copy,{recursive:true,filter:src=>!['.git','node_modules','backups','.rsync-tmp'].includes(path.basename(src))});
  const preserved='backups/pre-hub-test-readonly-data-2026-10-24/Hub.html';
  if(fs.existsSync(path.join(root,preserved))){fs.mkdirSync(path.dirname(path.join(copy,preserved)),{recursive:true});fs.copyFileSync(path.join(root,preserved),path.join(copy,preserved));}
  return work(copy);
 } finally { fs.rmSync(temp,{recursive:true,force:true}); }
}
function runTests(file){return isolatedCopy(testRoot=>{
 const r=cp.spawnSync(process.execPath,['--test','--test-reporter=tap',...discover(path.join(testRoot,'tests')).sort()],{cwd:testRoot,encoding:'utf8',maxBuffer:32*1024*1024,timeout:180000});
 const output=(r.stdout||'')+'\n'+(r.stderr||'');fs.writeFileSync(file,output);
 if(r.error||r.signal)throw Error('Test runner did not complete: '+(r.error?.message||r.signal));
 const failed=[...output.matchAll(/^not ok \d+ - (.*)$/gm)].map(m=>m[1]).sort();
 const count=Number(output.match(/^# tests (\d+)$/m)?.[1]);
 if(!Number.isFinite(count)||!count||(r.status!==0&&!failed.length))throw Error('Test output could not be verified.');
 return {tests:count,pass:Number(output.match(/^# pass (\d+)$/m)?.[1]),failed};
});}
let applied=[],backup,evidence;
try{
 if(fs.lstatSync(root).isSymbolicLink())throw Error('Choose the actual project folder.');
 if(JSON.parse(fs.readFileSync(path.join(root,'package.json'))).name!=='beauty-admin-hub')throw Error('Run from Beauty-Admin-Hub or supply its path.');
 const planned=manifest.files.map(item=>{
  const dest=safe(item.path),payload=path.join(bundle,'payload',item.path),bytes=fs.readFileSync(payload);
  if(hash(bytes)!==item.sha256)throw Error('Package integrity mismatch: '+item.path);
  const exists=fs.existsSync(dest),old=exists?fs.readFileSync(dest):null;
  if(!exists&&!item.allowNew)throw Error('Missing expected baseline: '+item.path);
  if(exists&&normalized(old)!==item.normalized&&!item.acceptedBefore.includes(normalized(old)))throw Error('Unrecognised local version; nothing installed: '+item.path);
  return {item,dest,bytes,old};
 });
 const changed=planned.filter(p=>!p.old||hash(p.old)!==p.item.sha256);
 if(!changed.length){console.log('ALREADY_INSTALLED: source files match this update. No changes.');process.exit(0);}
 const stamp=new Date().toISOString().replace(/[:.]/g,'-');backup=path.join(root,'backups','combined-hub-before-'+stamp);evidence=path.join(root,'evidence','combined-hub-install-'+stamp);
 fs.mkdirSync(backup,{recursive:true});fs.mkdirSync(evidence,{recursive:true});
 console.log('Checking existing tests and saving the baseline result…');const before=runTests(path.join(evidence,'before-tests.tap'));
 // Recheck all destinations after tests, before any source mutation.
 for(const p of planned){const now=fs.existsSync(p.dest)?fs.readFileSync(p.dest):null;if((now===null)!==(p.old===null)||(now&&hash(now)!==hash(p.old)))throw Error('Source changed during preflight: '+p.item.path);}
 fs.writeFileSync(path.join(backup,'restore-manifest.json'),JSON.stringify(changed.map(p=>({path:p.item.path,existed:!!p.old,installedSha256:p.item.sha256})),null,2));
 for(const p of changed){
  if(p.old){const save=path.join(backup,p.item.path);fs.mkdirSync(path.dirname(save),{recursive:true});fs.writeFileSync(save,p.old);}
  fs.mkdirSync(path.dirname(p.dest),{recursive:true});applied.push(p);fs.writeFileSync(p.dest,p.bytes);
 }
 console.log('Verifying the TEST Hub build in an isolated copy…');isolatedCopy(buildRoot=>{for(const script of ['scripts/build-hub-test.cjs','scripts/build-beauty-live.cjs'])cp.execFileSync(process.execPath,[script],{cwd:buildRoot,timeout:30000});for(const p of planned)if(hash(fs.readFileSync(path.join(buildRoot,p.item.path)))!==p.item.sha256)throw Error('Reproducible build mismatch: '+p.item.path);});
 for(const p of planned)if(hash(fs.readFileSync(p.dest))!==p.item.sha256)throw Error('Build/hash mismatch: '+p.item.path);
 console.log('Checking updated tests…');const after=runTests(path.join(evidence,'after-tests.tap'));
 const added=after.failed.filter(n=>!before.failed.includes(n));if(after.failed.length)throw Error('Post-install suite must be clean; update rolled back: '+after.failed.join('; '));
 const inventory=isolatedCopy(testRoot=>cp.spawnSync(process.execPath,['scripts/check-test-inventory.cjs'],{cwd:testRoot,encoding:'utf8',maxBuffer:32*1024*1024,timeout:180000}));
 fs.writeFileSync(path.join(evidence,'inventory.txt'),(inventory.stdout||'')+'\n'+(inventory.stderr||''));
 if(inventory.status!==0)throw Error('Inventory did not pass; update rolled back. See inventory.txt.');
 const result={result:after.failed.length?'LOCAL_COMBINED_HUB_INSTALL_PASS_WITH_EXISTING_FAILURES':'LOCAL_COMBINED_HUB_INSTALL_PASS',finishedUTC:new Date().toISOString(),before,after,newFailures:added,inventory:inventory.status===0?'PASS':'NOT_PASS — see inventory.txt',backup,evidence,files:changed.map(p=>p.item.path),googleUpload:'PENDING — copy changed Google files listed in READ-ME.txt to existing Identity TEST files only',deviceAcceptance:'PENDING — verify no Hub tournament assignment command, Live knockout display, plain labels and automatic pool board defaults; do not resend pools or repeat Start',production:'UNCHANGED'};
 fs.writeFileSync(path.join(evidence,'result.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}catch(e){
 for(const p of applied.reverse()){try{if(p.old)fs.writeFileSync(p.dest,p.old);else fs.unlinkSync(p.dest);}catch(rollback){console.error('RESTORE REQUIRED: '+p.dest+' — '+rollback.message);}}
 if(evidence)fs.writeFileSync(path.join(evidence,'STOP.txt'),e.stack||String(e));
 console.error('STOP: '+e.message);if(backup)console.error('Backup: '+backup);process.exitCode=1;
}
