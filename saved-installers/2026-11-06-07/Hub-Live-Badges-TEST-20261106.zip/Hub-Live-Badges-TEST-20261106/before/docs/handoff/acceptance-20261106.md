# Identity TEST acceptance — 6 November 2026

Event: AIK Hub TEST 2026-11-06, t_MGCo_7732, AIK league lg_tM2v_3523.
Owner evidence: screenshots and reports in this conversation. Production untouched.

## Observed

- Date selection, reviewed creation, empty event and preserved November 2 completed event verified by owner.
- Hub/Mobile/Kiosk registration and five native League entries verified.
- One pool of five, ten native Round Robin matches, reviewed transfer and start verified.
- Results entered through scorer and Nakka Control appeared in Live.
- Manual tied ranking resolved by owner. Top two to Slutspel 1; three remaining to Slutspel 2.
- Slutspel 1: Alessio Tampella defeated Thomas Wågberg 3–0, correct Live score and trophy.
- Slutspel 2: Jerrimi Hedblad defeated Christian Jonsson 2–0. Native Nakka confirmed result; Live stayed LIVE/0–0 after reload and showed champion early. FAIL.
- Board 1 present in both final displays, but styling unclear. Earlier Slutspel 2 semifinal badge absence not yet diagnosed against a native badge readback.
- Native third-place setting unnecessarily enabled for two-player Slutspel 1 final.
- Partial scoring data caused player/NU averages to disappear.

## This update — local verification only

797 tests passed; inventory tracked. Google TEST upload and device retest pending.

- Saved unequal bracket result overrides stale active scorer data.
- Champion display waits for unequal final result and no active Live flag; name still comes from Nakka's champion slot.
- Bye/pending player names blank; advancement preserved.
- Empty bronze section hidden; bronze section suppressed for two-slot-only bracket.
- Yellow/black board badge and smaller final-only card.
- Known point/dart averages preserved when other result-only matches lack stats. Partial coverage visibly marked; missing points/darts never invented. Malformed/ambiguous totals remain blocked.
- New TEST event defaults: join password AIK, common_join=1, individual_pass=0, game_type=5 (local scoring + submit results).
- Running competition hides Save Boards & Match Plan.
- Pool explanatory text wraps; mobile Tonight's Players digits embed AIK Siffror.

## Remaining authorised work

- Compact one-window Event Control: date lookup → connect existing or configure missing event → review → confirm.
- Custom event title; Round Robin only / knockout only / combined; group sizes including six or more; independent Slutspel brackets, qualifiers and third-place switch.
- First-to legs or sets per stage, plus round/final/third-place overrides; optional rounds/dart limit using native Nakka winner/draw/cancel prompt.
- Back buttons with preserved draft and invalidated approvals after edits.
- Clear inline errors and expired-review recovery; date-saved heading, separate action row, collapsed diagnostics, compact handoff.
- Retest Live against mixed manually entered averages and complete native stats; keep definitions and coverage explicit.
- Keep native Nakka admin/qualifier editing/automatic progression; explain autopilot window must remain open.
- Cleanup TEST events and dummy league players later, after review. Original November 2 TEST is still the creation template: decouple it before deleting.

## Required retest

Reload current completed TEST in Live: Slutspel 1 0–3 and Alessio winner; Slutspel 2 2–0 and Jerrimi winner, no LIVE highlight. Check badges, blank slots, hidden empty bronze, partial averages, mobile digits, and post-start button. No need to resend pools, repeat Start or recreate event.
