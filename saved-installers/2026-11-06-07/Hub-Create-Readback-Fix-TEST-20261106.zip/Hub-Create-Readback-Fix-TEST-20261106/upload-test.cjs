'use strict';
// Owner-authorised Identity TEST source upload. No deploy, run, properties or production calls.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process');
const SCRIPT='1toxHCexOm5xyillytqPLBidiv62PePvrX4EQROvWeTZddfjrUJGMem6N';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const normalize=b=>hash(Buffer.from(b.toString('utf8').replace(/\r\n/g,'\n').replace(/\n+$/,'')));
function files(root){
 const out={};
 function walk(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){
  if(item.name.startsWith('.'))continue;
  const p=path.join(dir,item.name);if(item.isSymbolicLink())throw Error('Unexpected symlink in Google clone.');
  if(item.isDirectory())walk(p);else if(/\.(js|gs|html|json)$/.test(item.name))out[path.relative(root,p).split(path.sep).join('/')]=normalize(fs.readFileSync(p));
 }}walk(root);return out;
}
function same(a,b){const keys=Object.keys(a).sort();return JSON.stringify(keys)===JSON.stringify(Object.keys(b).sort())&&keys.every(k=>a[k]===b[k]);}
function config(dir){const p=path.join(dir,'.clasp.json'),c=JSON.parse(fs.readFileSync(p));if(c.scriptId!==SCRIPT)throw Error('Wrong Apps Script project; stopped.');c.rootDir='.';fs.writeFileSync(p,JSON.stringify(c,null,2));}
function main(root,bundle=__dirname,run=(args,cwd)=>{
 const p=cp.spawnSync(process.platform==='win32'?'npx.cmd':'npx',['--yes','--package=@google/clasp@3.4.1','clasp',...args],{cwd,stdio:'inherit',shell:false});
 if(p.error||p.status!==0)throw Error('clasp did not complete. Check Google login/API access. No automatic retry.');
}){
 root=path.resolve(root);const manifest=JSON.parse(fs.readFileSync(path.join(bundle,'manifest.json'))),mapping=JSON.parse(fs.readFileSync(path.join(bundle,'google-files.json')));
 const targets=mapping.map(([source,target])=>{
  const rel='apps-script/registration-identity-test/remote-app/'+source,item=manifest.files.find(i=>i.path===rel),p=path.join(root,rel),bytes=fs.readFileSync(p);
  if(!item||hash(bytes)!==item.sha256)throw Error('Install the local update first: '+source);
  return {source,target,item,bytes};
 });
 const stamp=new Date().toISOString().replace(/[:.]/g,'-'),work=fs.mkdtempSync(path.join(root,'backups','google-live-fixes-'+stamp+'-'));
 const clone=name=>{const dir=path.join(work,name);fs.mkdirSync(dir);run(['clone-script',SCRIPT],dir);config(dir);if(!fs.existsSync(path.join(dir,'appsscript.json')))throw Error('Google manifest missing.');return dir;};
 const backup=clone('before'),before=files(backup),stage=path.join(work,'prepared');fs.cpSync(backup,stage,{recursive:true});config(stage);
 let changed=0;
 for(const t of targets){
  const native=t.target.replace(/\.gs$/,'.js'),candidates=Object.keys(before).filter(n=>n===native||n===t.target);
  if(candidates.length!==1)throw Error('Expected existing Google file missing or ambiguous: '+t.target);
  const name=candidates[0],actual=before[name];
  if(actual===t.item.normalized)continue;
  if(!t.item.acceptedBefore.includes(actual))throw Error('Unrecognised Google version: '+t.target+'. Nothing uploaded. Backup: '+work);
  fs.writeFileSync(path.join(stage,name),t.bytes);changed++;
 }
 const expected=files(stage),stateFile=path.join(bundle,'google-upload-state.json');
 const prior=fs.existsSync(stateFile)?JSON.parse(fs.readFileSync(stateFile)):null;
 if(changed){
  if(prior?.state==='ATTEMPTED')throw Error('Earlier upload outcome is unverified. Inspect Google before retrying.');
  const fresh=clone('pre-push-check');if(!same(before,files(fresh)))throw Error('Google changed during preparation. Nothing uploaded.');
  const receipt={state:'ATTEMPTED',scriptId:SCRIPT,backup:work,expected,startedUTC:new Date().toISOString()};fs.writeFileSync(stateFile,JSON.stringify(receipt,null,2));
  console.log('Uploading reviewed Identity TEST source; preserving all other Google files…');
  run(['push','--force'],stage);
 }
 const readback=clone('readback');if(!same(expected,files(readback)))throw Error('Google readback differs. Do not push again. Backup: '+work);
 const receipt={state:'VERIFIED',result:'GOOGLE_TEST_READBACK_VERIFIED',finishedUTC:new Date().toISOString(),scriptId:SCRIPT,filesVerified:Object.keys(expected).length,changedFiles:changed,backup:work,production:'UNCHANGED',deployment:'UNCHANGED'};
 fs.writeFileSync(stateFile,JSON.stringify(receipt,null,2));fs.writeFileSync(path.join(work,'result.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt,null,2));return receipt;
}
module.exports={main,same,files,SCRIPT};
if(require.main===module){try{
 const root=path.resolve(process.argv[2]||process.cwd());if(JSON.parse(fs.readFileSync(path.join(root,'package.json'))).name!=='beauty-admin-hub')throw Error('Choose Beauty-Admin-Hub.');
 const install=cp.spawnSync(process.execPath,[path.join(__dirname,'install.cjs'),root],{stdio:'inherit',shell:false});if(install.error||install.status!==0)throw Error('Local installation did not pass. Google untouched.');
 fs.mkdirSync(path.join(root,'backups'),{recursive:true});main(root);
}catch(e){console.error('STOP: '+e.message);process.exitCode=1;}}
