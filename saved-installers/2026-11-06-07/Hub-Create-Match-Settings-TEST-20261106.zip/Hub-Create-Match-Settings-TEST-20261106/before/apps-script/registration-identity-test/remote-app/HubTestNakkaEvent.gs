/* Identity TEST: date-matched TEST event selection and explicitly reviewed creation. */
function beautyHubNakkaDate_() {
  const ss = (typeof beautyHubSpreadsheet_==='function'?beautyHubSpreadsheet_():SpreadsheetApp.openById(SHEET_ID));
  if (ss.getId() !== SHEET_ID) throw new Error('identity');
  const zone = ss.getSpreadsheetTimeZone();
  if (zone !== 'Europe/Berlin') throw new Error('zone');
  const cell = ss.getSheetByName('Control').getRange('A2');
  const value = cell.getValue();
  if (cell.getFormula() || !(value instanceof Date) || !Number.isFinite(value.getTime())) throw new Error('date');
  return {date: Utilities.formatDate(value, zone, 'yyyy-MM-dd'), zone: zone};
}
function beautyHubNakkaEvent_(input) {
  beautyHubTestGuard_();
  beautyHubNakkaAuthorize_();
  if (!input || typeof input !== 'object' || Array.isArray(input) || Object.keys(input).length) throw new Error('Unexpected event input.');
  const answer = (status, message, date, event) => ({success:true, status:status, message:message,
    eventDate:date || '', event:event || null, readOnly:true, checkedAt:new Date().toISOString()});
  let selected;
  try { selected = beautyHubNakkaDate_(); } catch(e) { return answer('UNAVAILABLE','The TEST event date could not be read.'); }
  const props = PropertiesService.getScriptProperties();
  const user = props.getProperty('N01_API_USER'), password = props.getProperty('N01_API_PASSWORD');
  if (!user || !password) return answer('UNAVAILABLE','Nakka API credentials are not configured.',selected.date);
  let response;
  try {
    response = UrlFetchApp.fetch('https://push.n01darts.com/api/v1/league/tournament/list?lgid=lg_tM2v_3523&count=100', {
      method:'get', headers:{Authorization:'Basic '+Utilities.base64Encode(user+':'+password)},
      muteHttpExceptions:true, followRedirects:false
    });
  } catch(e) { return answer('UNAVAILABLE','Nakka events could not be reached.',selected.date); }
  const code = response.getResponseCode();
  if (code !== 200) return answer('UNAVAILABLE',code === 401 || code === 403 ? 'Nakka authentication failed.' : 'Nakka event lookup failed (HTTP '+code+').',selected.date);
  let data;
  try { data = JSON.parse(response.getContentText()); } catch(e) { return answer('UNAVAILABLE','Nakka returned an unreadable event response.',selected.date); }
  if (!data || data.result !== 0 || !Array.isArray(data.list) || data.list.length >= 100)
    return answer('UNAVAILABLE','The Nakka event list is invalid or may be incomplete. No event selected.',selected.date);
  const matches = [];
  for (const event of data.list) {
    if (!event || typeof event !== 'object' || Array.isArray(event))
      return answer('UNAVAILABLE','A Nakka event date needs review. No event selected.',selected.date);
    // Undated events cannot match a calendar date. Do not coerce strings.
    if (event.t_date === undefined || event.t_date === null || event.t_date === '' || event.t_date === 0) continue;
    if (typeof event.t_date !== 'number' || !Number.isFinite(event.t_date) || event.t_date < 0)
      return answer('UNAVAILABLE','A Nakka event date needs review. No event selected.',selected.date);
    const date = new Date(event.t_date * 1000);
    if (!Number.isFinite(date.getTime())) return answer('UNAVAILABLE','A Nakka event date needs review. No event selected.',selected.date);
    if (Utilities.formatDate(date,selected.zone,'yyyy-MM-dd') === selected.date) matches.push(event);
  }
  beautyHubNakkaAuthorize_();
  try { if (beautyHubNakkaDate_().date !== selected.date) return answer('STALE','The Hub date changed during lookup. Check again.'); }
  catch(e) { return answer('UNAVAILABLE','The TEST event date could not be rechecked.'); }
  // A live Monday tournament can share this date. It must never become the TEST target.
  if (matches.some(event => typeof event.tdid !== 'string' || !/^t_[A-Za-z0-9_]{1,80}$/.test(event.tdid)))
    return answer('UNAVAILABLE','The matching Nakka event details need review.',selected.date);
  const targets=matches.filter(event=>event.tdid==='t_QHaG_7792'||/^AIK Hub TEST(?: |$)/.test(event.title||''));
  if(!targets.length)return answer('NOT_FOUND','No TEST event exists for this date. You can review creating one.',selected.date);
  if(targets.length!==1)return answer('AMBIGUOUS','More than one TEST event matches this date. Select the intended event in Nakka before continuing.',selected.date);
  const match=targets[0];
  if(match.tdid==='t_QHaG_7792'&&match.title!=='Beauty Registration TEST event DO NOT USE LIVE')return answer('UNAVAILABLE','Original TEST identity changed.',selected.date);
  if(data.list.filter(e=>e.tdid===match.tdid).length!==1||match.lgid!==undefined&&match.lgid!=='lg_tM2v_3523')return answer('UNAVAILABLE','Event identity needs review.',selected.date);
  const binding={id:match.tdid,title:match.title,date:selected.date};
  props.setProperty('BEAUTY_SELECTED_TEST_EVENT',JSON.stringify(binding));
  return answer('MATCHED','The dedicated TEST event matches the selected Hub date. No players have been synced.',selected.date,
    {id:match.tdid,title:match.title,date:selected.date,url:'https://n01darts.com/n01/league/season.php?id='+encodeURIComponent(match.tdid)});
}

/* Compare names only. Equal names are not proof of permanent player identity. */
function beautyHubNakkaCompareNames_(hub, nakka) {
  const key = value => value.normalize('NFC').trim().replace(/\s+/g,' ').toLocaleLowerCase('sv-SE');
  const groups = new Map();
  for (const [side, rows] of [['hub',hub],['nakka',nakka]]) {
    for (const row of rows) {
      const k = key(row.name);
      if (!groups.has(k)) groups.set(k,{hub:[],nakka:[]});
      groups.get(k)[side].push(row);
    }
  }
  const result = {both:[],hubOnly:[],nakkaOnly:[],ambiguous:[]};
  for (const [k, group] of groups) {
    if (group.hub.length > 1 || group.nakka.length > 1) {
      result.ambiguous.push({name:(group.hub[0]||group.nakka[0]).name,hubCount:group.hub.length,nakkaCount:group.nakka.length});
    } else if (group.hub.length && group.nakka.length) result.both.push({name:group.hub[0].name,status:group.hub[0].status});
    else if (group.hub.length) result.hubOnly.push({name:group.hub[0].name,status:group.hub[0].status});
    else result.nakkaOnly.push({name:group.nakka[0].name});
  }
  for (const rows of Object.values(result)) rows.sort((a,b)=>a.name.localeCompare(b.name,'sv-SE'));
  return result;
}
function beautyHubNakkaHubRows_() {
  const ss = (typeof beautyHubSpreadsheet_==='function'?beautyHubSpreadsheet_():SpreadsheetApp.openById(SHEET_ID));
  if (ss.getId() !== SHEET_ID) throw new Error('identity');
  const sheet = ss.getSheetByName("TONIGHT'S PLAYERS");
  const count = sheet.getLastRow();
  if (count > 1001) throw new Error('size');
  // Read headers and roster together, freshly on every call.
  const rows = sheet.getRange(1,1,Math.max(1,count),3).getDisplayValues();
  if (JSON.stringify(rows[0]) !== JSON.stringify(['PLAYERS','NEW PLAYERS','STATUS'])) throw new Error('headers');
  if (count < 2) return [];
  return rows.slice(1).filter(row=>row[0]||row[1]).map(row=>{
    const name = String(row[0]||row[1]||'').trim();
    if (!name || name.length > 120 || /[\x00-\x1f\x7f]/.test(name)) throw new Error('name');
    return {name:name,status:String(row[2]||'').trim().slice(0,40)};
  });
}
function beautyHubNakkaCompare_(input) {
  beautyHubTestGuard_();
  beautyHubNakkaAuthorize_();
  if (!input || typeof input !== 'object' || Array.isArray(input) || Object.keys(input).length) throw new Error('Unexpected comparison input.');
  const eventResult = beautyHubNakkaEvent_({});
  if (eventResult.status !== 'MATCHED') return eventResult;
  const fail = message => ({success:true,status:'UNAVAILABLE',message:message,eventDate:eventResult.eventDate,event:null,readOnly:true,checkedAt:new Date().toISOString()});
  let hub;
  try { hub = beautyHubNakkaHubRows_(); } catch(e) { return fail('The TEST player list could not be read safely.'); }
  const props = PropertiesService.getScriptProperties(),user=props.getProperty('N01_API_USER'),password=props.getProperty('N01_API_PASSWORD');
  if (!user||!password) return fail('Nakka API credentials are not configured.');
  let response,data;
  try {
    response=UrlFetchApp.fetch('https://push.n01darts.com/api/v1/tournament/entry/list?tdid='+encodeURIComponent(eventResult.event.id),{
      method:'get',headers:{Authorization:'Basic '+Utilities.base64Encode(user+':'+password)},muteHttpExceptions:true,followRedirects:false});
    if(response.getResponseCode()!==200)return fail('Nakka event players could not be read (HTTP '+response.getResponseCode()+').');
    data=JSON.parse(response.getContentText());
  } catch(e) { return fail('Nakka returned no readable player list.'); }
  if (!data||data.result!==0||!Array.isArray(data.list)||data.list.length>1000) return fail('Nakka returned an invalid or oversized player list.');
  const nakka=[];
  for (const row of data.list) {
    if (!row||typeof row.name!=='string'||!row.name.trim()||row.name.length>120||/[\x00-\x1f\x7f]/.test(row.name))return fail('A Nakka player name needs review.');
    nakka.push({name:row.name.trim()});
  }
  beautyHubNakkaAuthorize_();
  try {
    if(beautyHubNakkaDate_().date!==eventResult.eventDate||JSON.stringify(beautyHubNakkaHubRows_())!==JSON.stringify(hub))
      return {success:true,status:'STALE',message:'The Hub date or players changed during comparison. Compare again.',event:null,readOnly:true,checkedAt:new Date().toISOString()};
  } catch(e) { return fail('The TEST player list could not be rechecked.'); }
  return Object.assign({},eventResult,{status:'COMPARED',message:'Name comparison only. All Hub statuses are included. No players have been synced.',hubCount:hub.length,nakkaCount:nakka.length,
    comparison:beautyHubNakkaCompareNames_(hub,nakka),checkedAt:new Date().toISOString()});
}


function beautyHubActiveTestTarget_(){
 const selected=beautyHubNakkaDate_(),v=JSON.parse(PropertiesService.getScriptProperties().getProperty('BEAUTY_SELECTED_TEST_EVENT')||'null');
 if(!v||v.date!==selected.date||!/^t_[A-Za-z0-9_]{1,80}$/.test(v.id)||!(v.id==='t_QHaG_7792'&&v.title==='Beauty Registration TEST event DO NOT USE LIVE'||/^AIK Hub TEST(?: |$)/.test(v.title||'')))throw Error('Check the Nakka event for the selected Hub date before continuing.');
 return v;
}

/* Explicit find-or-create review. Changing the date never creates an event. */
function beautyHubCreateEvent_(action,input){
 if(!['prepare','confirm'].includes(action))return {success:false,error:'Invalid event action.'};
 beautyHubTestGuard_();const lock=LockService.getScriptLock();if(!lock.tryLock(5000))return {success:false,error:'Another event operation is running.'};
 let attempted=false;const fail=message=>{throw {reviewMessage:message};};
 try{
  const account=beautyHubAuthRequire_(beautyHubRequestToken_),props=PropertiesService.getScriptProperties(),cache=CacheService.getScriptCache();
  const keys=action==='prepare'?'title':'confirmed,ticket';
  if(!input||Object.keys(input).sort().join(',')!==keys||Object.values(input).some(v=>typeof v!=='string'))fail('Invalid event request.');
  const date=beautyHubNakkaDate_().date,key='BEAUTY_CREATE_EVENT_'+date;
  if(props.getProperty(key))fail('An event creation is already recorded for this date. Check Nakka and its audit; do not create again.');
  const found=beautyHubNakkaEvent_({});if(found.status!=='NOT_FOUND')fail('An event already exists or the lookup is incomplete. Check Nakka again.');
  const auth=beautyPoolAuth_(),session=beautyPoolHash_(account.sessionBinding||beautyHubRequestToken_);
  if(action==='prepare'){
   if(!/^AIK Hub TEST(?: |$)/.test(input.title)||input.title.length>60||/[\x00-\x1f<>]/.test(input.title))fail('Use a TEST title of at most 60 characters.');
   const template=beautyHubTransferFetch_('tournament/get?tdid=t_QHaG_7792',auth).tournament;
   if(template?.tdid!=='t_QHaG_7792'||template.lgid!=='lg_tM2v_3523'||template.title!=='Beauty Registration TEST event DO NOT USE LIVE'||template.rr_setting?.round_robin!==1||template.team_games!==0||template.t_setting?.tournament!==1||template.s2_setting?.tournament!==1)fail('The approved TEST format template is unavailable.');
   const set={title:input.title,status:20,t_date:Date.parse(date+'T12:00:00Z')/1000,lgid:'lg_tM2v_3523',kind:'darts',team_games:0,game_type:5,private:0,join_pass:'AIK',common_join:1,individual_pass:0};
   for(const k of ['rr_setting','t_setting','s2_setting'])if(template[k])set[k]=beautyPoolCopy_(template[k]);
   const ticket=Utilities.getUuid().replace(/-/g,'');cache.put('beauty-create:'+ticket,JSON.stringify({uid:account.uid,session,date,set,expires:Date.now()+300000}),300);
   return {success:true,ticket,event:{title:set.title,date,format:'Round Robin + Slutspel 1 and 2',league:set.lgid,status:'Accepting entries',private:false},message:'Review this new TEST event. Existing players, results and brackets will not be copied.'};
  }
  const review=JSON.parse(cache.get('beauty-create:'+input.ticket)||'null');
  if(input.confirmed!=='true'||!review||review.uid!==account.uid||review.session!==session||review.date!==date||Date.now()>=review.expires)fail('Review expired. Review again to continue.');
  cache.remove('beauty-create:'+input.ticket);
  beautyHubAuthRequire_(beautyHubRequestToken_);
  const audit=beautyPoolAudit_({kind:'EVENT_CREATE_BEFORE',uid:account.uid,date,title:review.set.title,format:'RR_TWO_KNOCKOUTS',league:'lg_tM2v_3523'});
  const marker=JSON.stringify({state:'ATTEMPTED',audit,date,title:review.set.title});props.setProperty(key,marker);if(props.getProperty(key)!==marker)throw Error('Could not verify the creation journal.');
  attempted=true;
  const result=beautyHubTransferFetch_('tournament/create',auth,{set:review.set});
  if(!/^t_[A-Za-z0-9_]{1,80}$/.test(result.tdid||'')||result.tdid==='t_QHaG_7792')throw Error('Creation receipt is invalid.');
  const event=beautyHubTransferFetch_('tournament/get?tdid='+encodeURIComponent(result.tdid),auth).tournament;
  for(const k of ['title','status','t_date','lgid','team_games','game_type','private','common_join','individual_pass','join_pass'])if(event?.[k]!==review.set[k])throw Error('Created event readback differs.');
  const entries=beautyHubTransferFetch_('tournament/entry/list?tdid='+encodeURIComponent(result.tdid),auth).list;
  if(!Array.isArray(entries)||entries.length||event.tdid!==result.tdid||event.entry_list?.length)throw Error('Created event identity or entries differ.');
  for(const k of ['rr_setting','t_setting','s2_setting'])if(review.set[k]&&!beautyPoolEqual_(event[k],review.set[k]))throw Error('Created format differs.');
  for(const k of Object.keys(event))if(/_(table|result|rank)$/.test(k)&&!beautyPoolEmpty_(event[k]))throw Error('Created event contains unexpected play data.');
  if(beautyHubNakkaDate_().date!==date)throw Error('Date changed during creation.');
  const matched=beautyHubNakkaEvent_({});if(matched.status!=='MATCHED'||matched.event?.id!==result.tdid)throw Error('Created event selection could not be verified.');
  const receipt=beautyPoolAudit_({kind:'EVENT_CREATE_READBACK',audit,date,event:{id:event.tdid,title:event.title,status:event.status}});
  props.setProperty(key,JSON.stringify({state:'VERIFIED',audit,receipt,date,id:result.tdid}));
  return {success:true,event:matched.event,audit,receipt,message:'TEST event created once in Nakka and selected in Hub. No players or pools were sent.'};
 }catch(e){return {success:false,uncertain:attempted,error:attempted?'Event creation is unverified. Inspect Nakka and the creation journal. Do not retry.':(e.reviewMessage||'Could not review the event. Sign in again, then check Nakka and review again.')};}
 finally{lock.releaseLock();}
}
