/* Manual, read-only event and name comparison in the Identity TEST Hub. */
(() => {
  const button=document.getElementById('nakkaEventCheck'),compare=document.getElementById('nakkaCompare'),output=document.getElementById('nakkaEventResult');
  if(!compare||!output)return;
  let ticket=0,lastDate=null,lastPlayers=null;
  const dateNode=document.getElementById('currentEventDate');
  const snapshot=()=>JSON.stringify((window.beautyHubData?.players||[]).map(p=>[p.player,p.newPlayer,p.status]));
  const setBusy=busy=>{if(button)button.disabled=busy;compare.disabled=busy;};
  const reset=()=>{ticket++;lastDate=null;lastPlayers=null;output.replaceChildren();setBusy(false);};
  document.addEventListener('beauty-hub-locked',reset);
  const observe=()=>{if(lastDate!==null&&(dateNode?.textContent!==lastDate||(lastPlayers!==null&&snapshot()!==lastPlayers)))reset();};
  for(const node of [dateNode,document.getElementById('playersTableBody')])if(node)new MutationObserver(observe).observe(node,{childList:true,subtree:true,characterData:true});
  async function run(page,target=output){
    const paragraph=text=>{const p=document.createElement('p');p.textContent=text;target.append(p);};
    const focusResult=()=>{target.setAttribute?.('tabindex','-1');target.focus?.();target.scrollIntoView?.({block:'nearest'});};
    const current=++ticket,startedDate=dateNode?.textContent,startedPlayers=snapshot();setBusy(true);target.textContent='Checking Nakka…';
    try{
      const result=await(await BeautyHubServices.request('https://beauty.invalid/hub?page='+page)).json();
      if(current!==ticket)return;
      if(dateNode?.textContent!==startedDate||(page==='nakkacompare'&&snapshot()!==startedPlayers)){reset();target.textContent='The Hub date or players changed. Check again.';return;}
      target.replaceChildren();if(result.status!=='COMPARED')paragraph(result.message||'The event could not be checked.');
      if(result.status==='NOT_FOUND'){
        let draft='AIK Hub TEST '+(window.beautyHubData?.eventDate||''),revision=0;
        const showDraft=()=>{
          const version=++revision;target.replaceChildren();paragraph('No TEST event for '+(result.eventDate||window.beautyHubData?.eventDate||'this date')+'.');
          const name=document.createElement('input');name.value=draft;name.maxLength=60;name.setAttribute('aria-label','New TEST event name');target.append(name);
          const create=document.createElement('button');create.type='button';create.textContent='REVIEW CREATE EVENT';target.append(create);
          create.addEventListener('click',async()=>{
            if(create.disabled||current!==ticket||version!==revision)return;draft=name.value;create.disabled=true;name.disabled=true;
            try{
              const u=new URL('https://beauty.invalid/hub');u.searchParams.set('page','nakkacreateprepare');u.searchParams.set('title',draft);
              const p=await(await BeautyHubServices.request(u.toString())).json();if(current!==ticket||version!==revision)return;
              if(!p.success)throw Error(p.error||'Could not review the event. Try reviewing again.');
              target.replaceChildren();paragraph(p.event.title+' · '+p.event.date+' · '+p.event.format);paragraph('Public read-only TEST display. Players and results are not copied.');
              const back=document.createElement('button');back.type='button';back.textContent='BACK TO EVENT SETUP';target.append(back);
              back.addEventListener('click',()=>{if(back.disabled||current!==ticket)return;showDraft();});
              const label=document.createElement('label'),ack=document.createElement('input');ack.type='checkbox';label.append(ack,document.createTextNode(' Create this TEST event in Nakka.'));target.append(label);
              const confirm=document.createElement('button');confirm.type='button';confirm.textContent='CREATE EVENT — TEST';confirm.disabled=true;target.append(confirm);ack.addEventListener('change',()=>{confirm.disabled=!ack.checked;});
              confirm.addEventListener('click',async()=>{
                if(confirm.disabled||current!==ticket||version!==revision)return;confirm.disabled=true;ack.disabled=true;back.disabled=true;
                try{
                  const u=new URL('https://beauty.invalid/hub');u.searchParams.set('page','nakkacreateconfirm');u.searchParams.set('ticket',p.ticket);u.searchParams.set('confirmed','true');
                  const r=await(await BeautyHubServices.request(u.toString())).json();if(current!==ticket||version!==revision)return;
                  target.replaceChildren();paragraph(r.message||r.error||'Creation outcome unavailable. Inspect Nakka before retrying.');
                  if(r.success===false&&!r.uncertain){const retry=document.createElement('button');retry.type='button';retry.textContent='REVIEW AGAIN';retry.addEventListener('click',showDraft);target.append(retry);}
                  focusResult();
                }catch(e){if(current===ticket&&version===revision){target.replaceChildren();paragraph('Creation outcome unavailable. Inspect Nakka before retrying.');focusResult();}}
              });focusResult();
            }catch(e){if(current===ticket&&version===revision){paragraph(e.message);create.disabled=false;name.disabled=false;focusResult();}}
          });
        };showDraft();
      }
      if(result.status==='COMPARED'&&result.comparison){
        paragraph('Hub: '+result.hubCount+' · Nakka: '+result.nakkaCount+' · Snapshot: '+new Date(result.checkedAt).toLocaleString('en-GB',{timeZone:'Europe/Stockholm'}));
        paragraph('Matching names do not confirm permanent player identity. OUT and STANDBY remain visible for review.');
        for(const [key,title] of [['both','Same name on both lists'],['hubOnly','Hub only'],['nakkaOnly','Nakka only'],['ambiguous','Duplicate names — needs review']]){
          const rows=result.comparison[key];if(!Array.isArray(rows))throw Error('Invalid comparison');
          const section=document.createElement('details'),summary=document.createElement('summary');summary.textContent=title+' ('+rows.length+')';section.append(summary);
          if(rows.length){const list=document.createElement('ul');for(const row of rows){const item=document.createElement('li');item.textContent=row.name+(key==='ambiguous'?' — Hub '+row.hubCount+', Nakka '+row.nakkaCount:row.status?' — '+row.status:'');list.append(item);}section.append(list);}
          target.append(section);
        }
        lastPlayers=startedPlayers;
      }else lastPlayers=null;
      lastDate=dateNode?.textContent??'';focusResult();
    }catch(e){if(current===ticket){target.replaceChildren();paragraph('The Nakka check could not be completed. Sign in and try again.');}}
    finally{if(current===ticket)setBusy(false);}
  }
  button?.addEventListener('click',()=>run('nakkaevent'));
  window.BeautyNakkaEventCheck=target=>{if(!target)document.getElementById('nakkaNavButton')?.click();return run('nakkaevent',target||output);};
  window.BeautyNakkaEventCancel=()=>{ticket++;setBusy(false);};
  document.getElementById('nakkaSelectEvent')?.addEventListener('click',()=>window.BeautyNakkaEventCheck());
  compare.addEventListener('click',()=>run('nakkacompare'));
})();
