
// Authorized fixture for existing feature tests; auth itself is tested separately.
const authFixture={beautyHubActiveTestTarget_:()=>({id:'t_QHaG_7792',title:'Beauty Registration TEST event DO NOT USE LIVE'}),beautyHubCastHtml_:file=>({file,setTitle(){return this;}}),beautyHubAuthRequire_:()=>({uid:'fixture'}),beautyHubRequestToken_:'fixture',BeautyHubAuth:{token:()=> 'fixture',generation:()=>0,isCurrent:()=>true,expired(){}}};
process.chdir(require('node:path').resolve(__dirname, '..'));
const test=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'),vm=require('node:vm'),cp=require('node:child_process');
const base='apps-script/registration-identity-test/remote-app/';
const id='1toxHCexOm5xyillytqPLBidiv62PePvrX4EQROvWeTZddfjrUJGMem6N',sheet='1SIj4F8_WfWaeDVsdagRw8AoLsz0XsjhtdIn_OOxoDnU';
function server(o={}) {const calls=[];const c=vm.createContext({...authFixture,ScriptApp:{getScriptId:()=>id},getBeautyHubData_:()=>{calls.push('read');return {success:true,players:[{player:'Adam'}]};},submitRegistrationLocked_:i=>{calls.push(i);return {success:true};},...o});vm.runInContext(`const BEAUTY_IDENTITY_APPROVED_SCRIPT_='${o.approved||id}';const SHEET_ID='${o.sheet||sheet}';`+fs.readFileSync(base+'HubTestBridge.gs','utf8')+'\n'+fs.readFileSync(base+'HubTestAutoRegister.gs','utf8'),c);return {calls,call:(a,i)=>c.beautyHubTest(a,i)};}
function client(bridge){let success,failure;const runner={withSuccessHandler(fn){success=fn;return this;},withFailureHandler(fn){failure=fn;return this;},beautyHubTest(a,i){try{success(bridge(a,i));}catch(e){failure(e);}}};const c=vm.createContext({...authFixture,URL,google:{script:{run:runner}}});vm.runInContext(fs.readFileSync('public/js/hub-test-services.js','utf8')+'\nglobalThis.service=BeautyHubServices;',c);return c.service;}
test('Hub TEST rejects wrong running script before backend access',()=>{const s=server({ScriptApp:{getScriptId:()=> 'wrong'}});assert.throws(()=>s.call('read',{}),/identity mismatch/);assert.equal(s.calls.length,0);});
test('Hub TEST rejects wrong configured project and spreadsheet before backend access',()=>{for(const o of [{approved:'wrong'},{sheet:'wrong'}]){const s=server(o);assert.throws(()=>s.call('read',{}),/identity mismatch/);assert.equal(s.calls.length,0);}});
test('Hub TEST returns adapter data and TEST marker without registration',()=>{const s=server(),r=s.call('read',{});assert.equal(r.players[0].player,'Adam');assert.equal(r.mode,'test');assert.deepEqual(s.calls,['read']);});
test('Hub TEST rejects incomplete status, spoofed source and malformed input before I/O',()=>{const s=server();for(const [a,i] of [['status',{}],['read',{sheetId:sheet}],['register',{source:'KIOSK'}],['register',{message:3}],['read',null],['read',[]]])assert.throws(()=>s.call(a,i));assert.equal(s.calls.length,0);});
test('Hub TEST preserves confirmed identity and stamps HUB server-side',()=>{const s=server(),i={eventDate:'2026-10-27',selectedName:'Alessio Tampella',identityChoice:'different',identityBase:'Alessio Tampella',identityDetail:'test',identityConfirmedName:'Alessio Tampella (test)'};s.call('register',i);assert.deepEqual(JSON.parse(JSON.stringify(s.calls[0])),{...Object.fromEntries(Object.entries(i).filter(([k])=>k!=='eventDate')),source:'HUB',_expectedEventDate:'2026-10-27'});assert.equal(i.source,undefined);
 const h=actualRegistration(),payload={eventDate:'2026-10-27',selectedName:'MITT NAMN FINNS INTE I LISTAN',newName:'Demo Anna',consent:'NEJ, JAG GODKÄNNER INTE',message:'TEST-HUB'};
 assert.equal(h.context.beautyHubTest('register',payload).code,'NAME_CONFLICT');assert.equal(h.rows.length,0);
 const confirmed={...payload,identityChoice:'different',identityBase:'Demo Anna',identityDetail:'Karla',identityConfirmedName:'Demo Anna (Karla)'};
 assert.equal(h.context.beautyHubTest('register',confirmed).success,true);assert.equal(h.rows.length,1);assert.equal(h.rows[0][2],'Demo Anna (Karla)');assert.equal(h.rows[0][5],'HUB');assert.equal(h.rows[0][3],'NEJ, JAG GODKÄNNER INTE');
 const duplicate={eventDate:'2026-10-27',selectedName:'Demo Anna',identityChoice:'existing',identityBase:'Demo Anna',consent:'JA, JAG GODKÄNNER',message:'DO NOT SAVE'};
 assert.equal(h.context.beautyHubTest('register',duplicate).code,'ALREADY_REGISTERED');assert.equal(h.rows.length,1);
});
// Run the actual configured registration core through the bridge with fake Sheets.
function actualRegistration() {
 const rows=[],master=['Demo Anna'],tonight=['Demo Anna'];
 const sheetFor=(name,values)=>({getLastRow:()=>values.length+1,getRange:()=>({getDisplayValues:()=>values.map(v=>name==='tonight'?[v,'']:[v])}),appendRow:row=>rows.push(row)});
 const sheets={"PLAYER'S MASTER LIST":sheetFor('master',master),"TONIGHT'S PLAYERS":sheetFor('tonight',tonight),'Form responses 2':sheetFor('responses',[])};
 const context=vm.createContext({...authFixture,console,Date,ScriptApp:{getScriptId:()=>id},LockService:{getScriptLock:()=>({tryLock:()=>true,releaseLock(){}})},SpreadsheetApp:{openById:actual=>{assert.equal(actual,sheet);return {getSheetByName:n=>sheets[n]};},flush(){}}});
 vm.runInContext(fs.readFileSync(base+'Code.js','utf8')+'\n'+fs.readFileSync(base+'HubTestBridge.gs','utf8')+'\n'+fs.readFileSync(base+'HubTestAutoRegister.gs','utf8'),context);
 context.beautyHubRegistrationDateCheck_=()=>({success:true,eventDate:'2026-10-27'});
 context.addPlayerToMasterList_=n=>master.push(n);context.updatePlayerStatusData_=n=>tonight.push(n);context.syncTonightStatusDisplay_=()=>{};
 return {context,rows,master};
}
test('Hub TEST registration reuses Remote gate and lock with guaranteed release',()=>{const code=fs.readFileSync(base+'Code.js','utf8'),wrapper=code.slice(code.indexOf('function submitRegistration(data)'),code.indexOf('function syncMasterListToGoogleForm'));for(const scenario of ['ok','gate','busy','error']){const events=[],c=vm.createContext({...authFixture,ScriptApp:{getScriptId:()=>id},LockService:{getScriptLock:()=>({tryLock:()=>{events.push('lock');return scenario!=='busy';},releaseLock:()=>events.push('release')})},submitRegistrationIdentityCandidate_:()=>{events.push('write');if(scenario==='error')throw Error('failure');return {success:true};}});vm.runInContext(`const BEAUTY_IDENTITY_APPROVED_SCRIPT_='${id}';const BEAUTY_IDENTITY_WRITES_ENABLED_=${scenario!=='gate'};`+wrapper,c);if(scenario==='error')assert.throws(()=>c.submitRegistrationLocked_({}),/failure/);else assert.equal(c.submitRegistrationLocked_({}).success,scenario==='ok');assert.deepEqual(events,scenario==='gate'?[]:scenario==='busy'?['lock']:['lock','write','release']);}});
test('Hub TEST client reads and registers through RPC',async()=>{const calls=[],s=client((a,i)=>{calls.push([a,i]);return {success:true};});assert.equal((await(await s.request(s.endpoint)).json()).success,true);await s.request('https://beauty.invalid/hub?page=hubregister&selectedName=Adam');assert.deepEqual(JSON.parse(JSON.stringify(calls)),[['read',{}],['register',{selectedName:'Adam'}]]);assert.equal(s.statusWrites,true);});
test('Hub TEST client blocks foreign URLs, duplicate keys and source spoofing',async()=>{let count=0;const s=client(()=>{count++;});for(const url of ['https://evil.example/hub?page=hubdata','https://beauty.invalid/hub?page=hubstatus&sheetId=wrong','https://beauty.invalid/hub?page=hubdata&page=hubdata','https://beauty.invalid/hub?page=hubregister&source=MOBIL'])await assert.rejects(s.request(url),/Blocked/);assert.equal(count,0);});
test('Hub TEST RPC failure is sanitized and registration is never retried automatically',async()=>{let count=0;const s=client(()=>{count++;throw Error('secret');});await assert.rejects(s.request('https://beauty.invalid/hub?page=hubregister'),e=>!e.message.includes('secret')&&e.message.includes('Reload'));assert.equal(count,1);});
test('Hub TEST Nakka health uses guarded read-only RPC',async()=>{let healthCalls=0;const serverSide=server({getNakkaHealth_:()=>{healthCalls++;return {status:'OK',message:'Connected',timestamp:'2026-10-26T14:00:00Z'};}});const s=client((a,i)=>{assert.equal(a,'nakkahealth');assert.equal(Object.keys(i).length,0);return serverSide.call(a,i);});assert.equal((await(await s.request('https://beauty.invalid/hub?page=nakkahealth')).json()).status,'OK');assert.equal(healthCalls,1);assert.equal(serverSide.calls.length,0);assert.throws(()=>serverSide.call('nakkahealth',{event:'spoof'}));assert.equal(healthCalls,1);const wrong=server({ScriptApp:{getScriptId:()=> 'wrong'},getNakkaHealth_:()=>{throw Error('Must not contact Nakka');}});assert.throws(()=>wrong.call('nakkahealth',{}),/identity mismatch/);});
test('Hub TEST HTML is reproducible with parseable scripts and original AIK assets',()=>{const file=base+'HubTest.html',before=fs.readFileSync(file,'utf8');cp.execFileSync(process.execPath,['scripts/build-hub-test.cjs']);assert.equal(fs.readFileSync(file,'utf8'),before);const scripts=[...before.matchAll(/<script>\n([\s\S]*?)<\/script>/g)];assert.equal(scripts.length,19);for(const [,js]of scripts)new vm.Script(js);assert.match(before,/select.disabled = true/);assert.match(before,/TEST CONNECTED/);assert.match(before,/data:font\/woff2;base64/);assert.doesNotMatch(before,/<script src=|<link rel="stylesheet"/);assert.match(before,/Registration and status changes/);});
test('Hub TEST route is additive and manifest stays owner-only with legacy status RPC private',()=>{const code=fs.readFileSync(base+'Code.js','utf8'),route=code.slice(0,code.indexOf('/* CANDIDATE')),c=vm.createContext({...authFixture,ScriptApp:{getScriptId:()=>id},HtmlService:{createHtmlOutputFromFile:file=>({file,addMetaTag(){return this;},setTitle(){return this;}})},beautyHubTestGuard_:()=>{}});vm.runInContext(`const BEAUTY_IDENTITY_APPROVED_SCRIPT_='${id}';`+route,c);assert.equal(c.doGet({parameter:{}}).file,'RemoteRegistration');assert.equal(c.doGet({parameter:{page:'hub'}}).file,'HubTest');assert.throws(()=>c.doGet({parameter:{page:'hub',sheet:'wrong'}}));assert.doesNotMatch(code,/function updateBeautyHubPlayerStatus\(/);const m=JSON.parse(fs.readFileSync(base+'appsscript.json'));assert.equal(m.webapp.access,'MYSELF');assert.equal(m.webapp.executeAs,'USER_ACCESSING');});
test('Hub TEST tournament routes preserve audit guidance and reject caller supplied event targets',async()=>{
 const calls=[],s=client((action,input)=>{calls.push({action,input});return {success:false,uncertain:true,error:'Inspect TEST assignment audit.',audit:'POOL-TEST'};});
 for(const page of ['poolcontrol','poolqualifyprepare','poolqualifysave']){
  const query=page==='poolqualifysave'?'&ticket=abc&confirmed=true':'',r=await(await s.request('https://beauty.invalid/hub?page='+page+query)).json();assert.equal(r.error,'Inspect TEST assignment audit.');assert.equal(r.audit,'POOL-TEST');
  await assert.rejects(s.request('https://beauty.invalid/hub?page='+page+query+'&tdid=live'),/Blocked/);
 }
 assert.deepEqual(calls.map(c=>c.action),['poolcontrol','poolqualifyprepare','poolqualifysave']);
 const bridge=server({beautyHubPool_:(action,input)=>({action,input})});for(const action of calls.map(c=>c.action))assert.equal(bridge.call(action,{}).action,action);
});


test('Hub TEST pool board requests carry draft plans and running revision through the real client route',async()=>{
 const calls=[],s=client((action,input)=>{calls.push({action,input});return {success:true};});
 const plan=JSON.stringify({available:[1,4,6],choices:[{poolId:'a',boards:[1]},{poolId:'b',boards:[4,6]}]});
 for(const [page,input]of [['poolprepare',{ticket:'ticket',format:'top2-rest',boardPlan:plan}],['poolboardplan',{boardPlan:plan,boardVersion:'revision'}]]){
  const u=new URL('https://beauty.invalid/hub');u.searchParams.set('page',page);for(const [k,v]of Object.entries(input))u.searchParams.set(k,v);
  assert.equal((await(await s.request(u.toString())).json()).success,true);
  assert.deepEqual(JSON.parse(JSON.stringify(calls.at(-1))),{action:page,input});
  u.searchParams.set('tdid','production');await assert.rejects(s.request(u.toString()),/Blocked TEST route/);
 }
 assert.equal(calls.length,2);
});


test('generated Hub omits tournament assignment commands while retaining Live navigation and event date controls',()=>{
 const html=fs.readFileSync(base+'HubTest.html','utf8');
 assert.doesNotMatch(html,/ASSIGN KNOCKOUTS|REVIEW QUALIFIERS|TOURNAMENT CONTROL|BeautyTournamentControl/);
 assert.match(html,/CONFIRM DATE CHANGE/);assert.match(html,/START EVENT — TEST/);assert.match(html,/SAVE BOARDS & MATCH PLAN/);
 assert.match(html,/openBeautyLive|Live/);
});
