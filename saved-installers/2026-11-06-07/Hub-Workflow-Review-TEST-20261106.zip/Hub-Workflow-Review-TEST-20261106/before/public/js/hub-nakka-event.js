/* Manual, read-only event and name comparison in the Identity TEST Hub. */
(() => {
  const button=document.getElementById('nakkaEventCheck'),compare=document.getElementById('nakkaCompare'),output=document.getElementById('nakkaEventResult');
  if(!compare||!output)return;
  let ticket=0,lastDate=null,lastPlayers=null;
  const dateNode=document.getElementById('currentEventDate');
  const snapshot=()=>JSON.stringify((window.beautyHubData?.players||[]).map(p=>[p.player,p.newPlayer,p.status]));
  const setBusy=busy=>{if(button)button.disabled=busy;compare.disabled=busy;};
  const reset=()=>{ticket++;lastDate=null;lastPlayers=null;output.replaceChildren();setBusy(false);};
  document.addEventListener('beauty-hub-locked',reset);
  const observe=()=>{if(lastDate!==null&&(dateNode?.textContent!==lastDate||(lastPlayers!==null&&snapshot()!==lastPlayers)))reset();};
  for(const node of [dateNode,document.getElementById('playersTableBody')])if(node)new MutationObserver(observe).observe(node,{childList:true,subtree:true,characterData:true});
  const paragraph=text=>{const p=document.createElement('p');p.textContent=text;output.append(p);};
  async function run(page){
    const current=++ticket,startedDate=dateNode?.textContent,startedPlayers=snapshot();setBusy(true);output.textContent='Checking Nakka…';
    try{
      const result=await(await BeautyHubServices.request('https://beauty.invalid/hub?page='+page)).json();
      if(current!==ticket)return;
      if(dateNode?.textContent!==startedDate||(page==='nakkacompare'&&snapshot()!==startedPlayers)){reset();output.textContent='The Hub date or players changed. Check again.';return;}
      output.replaceChildren();if(result.status!=='COMPARED')paragraph(result.message||'The event could not be checked.');
      if(result.status==='NOT_FOUND'){
        const name=document.createElement('input');name.value='AIK Hub TEST '+(window.beautyHubData?.eventDate||'');name.maxLength=60;name.setAttribute('aria-label','New TEST event name');output.append(name);
        const create=document.createElement('button');create.textContent='REVIEW CREATE EVENT';output.append(create);
        create.addEventListener('click',async()=>{create.disabled=true;try{
          const u=new URL('https://beauty.invalid/hub');u.searchParams.set('page','nakkacreateprepare');u.searchParams.set('title',name.value);
          const p=await(await BeautyHubServices.request(u.toString())).json();if(!p.success)throw Error(p.error);if(current!==ticket)return;
          output.replaceChildren();paragraph(p.message);paragraph(p.event.title+' · '+p.event.date+' · '+p.event.format+' · Public read-only TEST display');
          const label=document.createElement('label'),ack=document.createElement('input');ack.type='checkbox';label.append(ack,document.createTextNode(' I confirm creating this TEST event with a public read-only display in Nakka.'));output.append(label);
          const confirm=document.createElement('button');confirm.textContent='CREATE EVENT — TEST';confirm.disabled=true;output.append(confirm);ack.addEventListener('change',()=>{confirm.disabled=!ack.checked;});
          confirm.addEventListener('click',async()=>{confirm.disabled=true;ack.disabled=true;try{const u=new URL('https://beauty.invalid/hub');u.searchParams.set('page','nakkacreateconfirm');u.searchParams.set('ticket',p.ticket);u.searchParams.set('confirmed','true');const r=await(await BeautyHubServices.request(u.toString())).json();if(current!==ticket)return;output.replaceChildren();paragraph(r.message||r.error);}catch(e){paragraph('Creation outcome unavailable. Inspect Nakka before retrying.');}});
        }catch(e){paragraph(e.message);} });
      }
      if(result.status==='COMPARED'&&result.comparison){
        paragraph('Hub: '+result.hubCount+' · Nakka: '+result.nakkaCount+' · Snapshot: '+new Date(result.checkedAt).toLocaleString('en-GB',{timeZone:'Europe/Stockholm'}));
        paragraph('Matching names do not confirm permanent player identity. OUT and STANDBY remain visible for review.');
        for(const [key,title] of [['both','Same name on both lists'],['hubOnly','Hub only'],['nakkaOnly','Nakka only'],['ambiguous','Duplicate names — needs review']]){
          const rows=result.comparison[key];if(!Array.isArray(rows))throw Error('Invalid comparison');
          const section=document.createElement('details'),summary=document.createElement('summary');summary.textContent=title+' ('+rows.length+')';section.append(summary);
          if(rows.length){const list=document.createElement('ul');for(const row of rows){const item=document.createElement('li');item.textContent=row.name+(key==='ambiguous'?' — Hub '+row.hubCount+', Nakka '+row.nakkaCount:row.status?' — '+row.status:'');list.append(item);}section.append(list);}
          output.append(section);
        }
        lastPlayers=startedPlayers;
      }else lastPlayers=null;
      lastDate=dateNode?.textContent??'';
    }catch(e){if(current===ticket){output.replaceChildren();paragraph('The Nakka check could not be completed. Sign in and try again.');}}
    finally{if(current===ticket)setBusy(false);}
  }
  button?.addEventListener('click',()=>run('nakkaevent'));
  window.BeautyNakkaEventCheck=()=>{document.getElementById('nakkaNavButton')?.click();const advanced=document.getElementById('nakkaComparisonDetails');if(advanced)advanced.open=true;output.scrollIntoView?.({block:'center'});return run('nakkaevent');};
  document.getElementById('nakkaSelectEvent')?.addEventListener('click',()=>window.BeautyNakkaEventCheck());
  compare.addEventListener('click',()=>run('nakkacompare'));
})();
