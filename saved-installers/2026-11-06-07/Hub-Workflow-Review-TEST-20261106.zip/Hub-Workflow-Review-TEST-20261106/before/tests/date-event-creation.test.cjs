const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),crypto=require('node:crypto');
const source=fs.readFileSync('apps-script/registration-identity-test/remote-app/HubTestNakkaEvent.gs','utf8');
const clone=x=>JSON.parse(JSON.stringify(x));
function fixture(o={}){
 const props=new Map([['N01_API_USER','secret-user'],['N01_API_PASSWORD','secret-password']]),cache=new Map(),calls=[],audits=[];
 const state={date:'2026-11-08',uid:'owner',session:'session',events:[],created:null,serial:0};
 const template={tdid:'t_QHaG_7792',title:'Beauty Registration TEST event DO NOT USE LIVE',lgid:'lg_tM2v_3523',team_games:0,rr_setting:{round_robin:1,robin_count:2,robin_player_count:4},t_setting:{tournament:1,t_player_count:4,t3:1,limit_leg_count:3},s2_setting:{tournament:1,t_player_count:4,limit_leg_count:2},rr_table:[['OLD']],rr_result:{OLD:{score:2}},entry_list:[{tpid:'OLD'}]};
 const c={Date,Map,JSON,Number,Object,Array,encodeURIComponent,SHEET_ID:'sheet',beautyHubRequestToken_:'token',
  beautyHubTestGuard_(){if(o.guard)throw Error('wrong project');},beautyHubNakkaAuthorize_(){if(o.auth)throw Error('not signed in');},
  beautyHubAuthRequire_(){if(o.auth)throw Error('secret');return {uid:state.uid,sessionBinding:state.session};},
  LockService:{getScriptLock:()=>({tryLock:()=>!o.busy,releaseLock(){}})},
  PropertiesService:{getScriptProperties:()=>({getProperty:k=>props.get(k)||null,setProperty:(k,v)=>{if(o.propertyFailure)throw Error('secret');props.set(k,v);}})},
  CacheService:{getScriptCache:()=>({get:k=>cache.get(k)||null,put:(k,v)=>cache.set(k,v),remove:k=>cache.delete(k)})},
  Utilities:{getUuid:()=>String(++state.serial).padStart(32,'0'),base64Encode:v=>Buffer.from(v).toString('base64'),formatDate:d=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Berlin',year:'numeric',month:'2-digit',day:'2-digit'}).format(d)},
  UrlFetchApp:{fetch:(url,input)=>{calls.push({url,input});assert.equal(input.method,'get');return {getResponseCode:()=>200,getContentText:()=>JSON.stringify({result:0,list:state.events})};}},
  beautyPoolAuth_:()=> 'authorization',beautyPoolCopy_:clone,beautyPoolHash_:v=>crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex'),beautyPoolEqual_:(a,b)=>JSON.stringify(a)===JSON.stringify(b),
  beautyPoolEmpty_:v=>v==null||v===''||Array.isArray(v)&&v.every(c.beautyPoolEmpty_)||typeof v==='object'&&Object.values(v).every(c.beautyPoolEmpty_),
  beautyPoolAudit_:v=>{audits.push(v);if(o.auditFailure)throw Error('secret');return 'audit-'+audits.length;},
  beautyHubTransferFetch_:(path,auth,payload)=>{
   calls.push({path,payload:payload&&clone(payload)});
   if(path==='tournament/get?tdid=t_QHaG_7792')return {tournament:clone(template)};
   if(path==='tournament/create'){
    assert.equal(JSON.parse(props.get('BEAUTY_CREATE_EVENT_'+state.date)).state,'ATTEMPTED');
    assert.deepEqual(Object.keys(payload),['set']);assert.equal(payload.set.private,0);assert.equal(payload.set.status,20);assert.equal(payload.set.join_pass,'AIK');assert.equal(payload.set.game_type,5);assert.equal(payload.set.common_join,1);assert.equal(payload.set.individual_pass,0);
    for(const k of Object.keys(payload.set))assert(!/table|result|rank|entry/.test(k));
    state.created={...clone(payload.set),tdid:'t_NEW_2026',rr_table:[],t_table:[],s2_table:[]};
    state.events.push(clone(state.created));
    if(o.timeout)throw Error('secret-password');
    if(o.readbackMismatch)state.created.title='Unexpected';
    if(o.duplicate)state.events.push({...clone(state.created),tdid:'t_SECOND'});
    return {result:0,tdid:'t_NEW_2026'};
   }
   if(path==='tournament/get?tdid=t_NEW_2026')return {tournament:clone(state.created)};
   if(path==='tournament/entry/list?tdid=t_NEW_2026')return {list:o.nonempty?[{tpid:'BAD'}]:[]};
   throw Error('secret unexpected path '+path);
  }};
 vm.createContext(c);vm.runInContext(source,c);c.beautyHubNakkaDate_=()=>({date:state.date,zone:'Europe/Berlin'});
 const prepare=()=>c.beautyHubCreateEvent_('prepare',{title:'AIK Hub TEST 8 November'});
 const confirm=p=>c.beautyHubCreateEvent_('confirm',{confirmed:'true',ticket:p.ticket});
 return {c,state,props,cache,calls,audits,template,prepare,confirm,posts:()=>calls.filter(v=>v.payload)};
}
test('Date events select a new approved TEST event and refuse a stale binding after the Hub date changes',()=>{
 const f=fixture();f.state.events=[{tdid:'t_NEW_2026',title:'AIK Hub TEST Sunday',lgid:'lg_tM2v_3523',t_date:Date.parse('2026-11-08T12:00Z')/1000}];
 assert.equal(f.c.beautyHubNakkaEvent_({}).event.id,'t_NEW_2026');assert.equal(f.c.beautyHubActiveTestTarget_().id,'t_NEW_2026');f.state.date='2026-11-09';assert.throws(()=>f.c.beautyHubActiveTestTarget_());assert.equal(f.posts().length,0);
});
test('Date creation review copies settings only and discloses public TEST visibility without any POST',()=>{
 const f=fixture(),p=f.prepare();assert.equal(p.success,true);assert.equal(p.event.private,false);assert.equal(p.event.status,'Accepting entries');assert.equal(f.posts().length,0);assert.equal(f.props.has('BEAUTY_CREATE_EVENT_'+f.state.date),false);assert.doesNotMatch(JSON.stringify(p),/secret|join_pass|OLD|Authorization/);
});
test('Date creation confirms once and verifies empty native entries plus settings before publishing the selection',()=>{
 const f=fixture(),p=f.prepare(),before=clone(f.template),r=f.confirm(p);assert.equal(r.success,true,JSON.stringify(r));assert.equal(r.event.id,'t_NEW_2026');assert.equal(f.posts().length,1);assert.equal(f.c.beautyHubActiveTestTarget_().id,'t_NEW_2026');assert.equal(JSON.parse(f.props.get('BEAUTY_CREATE_EVENT_'+f.state.date)).state,'VERIFIED');assert.deepEqual(f.template,before);assert.equal(f.confirm(p).success,false);assert.equal(f.posts().length,1);assert.doesNotMatch(JSON.stringify(f.audits),/secret|join_pass/);
});
test('Date creation rejects missing acknowledgement altered dates sessions users and expired tickets before POST',()=>{
 for(const mutate of [f=>f.state.date='2026-11-09',f=>f.state.session='another',f=>f.state.uid='another',f=>{const [key,value]=[...f.cache][0];const r=JSON.parse(value);r.expires=0;f.cache.set(key,JSON.stringify(r));}]){const f=fixture(),p=f.prepare();mutate(f);assert.equal(f.confirm(p).success,false);assert.equal(f.posts().length,0);}
 const f=fixture(),p=f.prepare();assert.equal(f.c.beautyHubCreateEvent_('confirm',{ticket:p.ticket,confirmed:'false'}).success,false);assert.equal(f.posts().length,0);
});
test('Date creation timeout leaves a durable uncertain marker and every later create attempt stays read only',()=>{
 const f=fixture({timeout:true}),p=f.prepare(),r=f.confirm(p);assert.equal(r.uncertain,true);assert.match(r.error,/Do not retry/);assert.doesNotMatch(JSON.stringify(r),/secret/);assert.equal(JSON.parse(f.props.get('BEAUTY_CREATE_EVENT_'+f.state.date)).state,'ATTEMPTED');assert.equal(f.prepare().success,false);assert.equal(f.confirm(p).success,false);assert.equal(f.posts().length,1);
});
test('Date creation blocks duplicate selection nonempty entries or changed native readbacks after its single POST',()=>{
 for(const options of [{duplicate:true},{nonempty:true},{readbackMismatch:true}]){const f=fixture(options),r=f.confirm(f.prepare());assert.equal(r.success,false);assert.equal(r.uncertain,true);assert.equal(f.posts().length,1);assert.equal(f.prepare().success,false);}
});
test('Date creation refuses an existing TEST event and cannot target same-date production or arbitrary input IDs',()=>{
 const f=fixture();f.state.events=[{tdid:'t_PRODUCTION',title:'Monday competition',lgid:'lg_tM2v_3523',t_date:Date.parse('2026-11-08T12:00Z')/1000}];assert.equal(f.c.beautyHubNakkaEvent_({}).status,'NOT_FOUND');
 assert.equal(f.c.beautyHubCreateEvent_('prepare',{title:'AIK Hub TEST',id:'t_PRODUCTION'}).success,false);assert.equal(f.c.beautyHubCreateEvent_('prepare',{title:'Production tournament'}).success,false);
 f.state.events.push({...f.state.events[0],tdid:'t_EXISTS',title:'AIK Hub TEST existing'});assert.equal(f.prepare().success,false);assert.equal(f.posts().length,0);
});
test('Date creation cannot POST if project authorization lock audit or journal verification fails',()=>{
 for(const option of ['guard','auth','busy','auditFailure','propertyFailure']){const o={},f=fixture(o);const p=f.prepare();o[option]=true;try{assert.equal(f.confirm(p).success,false);}catch(e){assert.equal(option,'guard');}assert.equal(f.posts().length,0);}
});

test('Cast staff opener forwards only its verified session to date selection and restores request context',()=>{
 const f=fixture();vm.runInContext(fs.readFileSync('apps-script/registration-identity-test/remote-app/BeautyLiveTest.gs','utf8'),f.c);
 f.c.beautyHubRequestToken_='prior';let seen;f.c.beautyHubNakkaEvent_=()=>{seen=f.c.beautyHubRequestToken_;return {status:'MATCHED'};};f.c.beautyHubSelectCastEvent_('verified-staff-token');assert.equal(seen,'verified-staff-token');assert.equal(f.c.beautyHubRequestToken_,'prior');
 f.c.beautyHubNakkaEvent_=()=>{throw Error('network');};assert.throws(()=>f.c.beautyHubSelectCastEvent_('other'));assert.equal(f.c.beautyHubRequestToken_,'prior');
});
test('Selected TEST Live feed requests only its injected event and rejects a different provider event',async()=>{
 const paths=[],id='t_SUNDAY_NEW',c={BeautySelectedEventId:id,BeautyNakkaStages:require('../public/js/nakka-stage-model.js'),AbortSignal,Date};vm.createContext(c);vm.runInContext(fs.readFileSync('public/js/nakka-stage-feed.js','utf8'),c);
 let shown,failed=false,wrong=false;
 const feed=c.BeautyNakkaStageFeed.create({fetch:async url=>{paths.push(url);return {ok:true,json:async()=>url.includes('standings?')?{result:0,tdid:id,groups:[]}:{result:0,tournament:{tdid:wrong?'t_QHaG_7792':id,lgid:'lg_tM2v_3523',title:'AIK Hub TEST Sunday',updateTime:1,entry_list:[]}}};},onData:d=>shown=d,onError:()=>failed=true});
 await feed.refresh();assert.equal(failed,false);assert.equal(shown.eventId,id);assert(paths.every(p=>p.endsWith('tdid='+id)));wrong=true;await feed.refresh();assert.equal(failed,true);
});
test('Missing-event UI reviews creation separately and sends exactly one explicitly acknowledged confirm',async()=>{
 class Node{constructor(tag){this.tag=tag;this.children=[];this.events={};this.disabled=false;this._text='';}set textContent(v){this._text=v;this.children=[];}get textContent(){return this._text;}append(...nodes){this.children.push(...nodes);}replaceChildren(){this.children=[];this._text='';}setAttribute(){}addEventListener(k,fn){this.events[k]=fn;}fire(k='click'){if(!this.disabled)return this.events[k]?.();}}
 const host=new Node('section'),check=new Node('button'),compare=new Node('button'),date=new Node('p'),calls=[];date.textContent='8 November 2026';
 const replies=[{status:'NOT_FOUND',message:'Missing TEST event'},{success:true,ticket:'ticket',message:'Review',event:{title:'AIK Hub TEST Sunday',date:'2026-11-08',format:'Round Robin + Slutspel 1 and 2'}},{success:true,message:'Created once'}];
 const c={URL,Date,JSON,window:{beautyHubData:{eventDate:'2026-11-08',players:[]}},document:{getElementById:id=>({nakkaEventCheck:check,nakkaCompare:compare,nakkaEventResult:host,currentEventDate:date}[id]),addEventListener(){},createElement:t=>new Node(t),createTextNode:t=>t},MutationObserver:class{observe(){}},BeautyHubServices:{request:async url=>{calls.push(new URL(url));return {json:async()=>replies.shift()};}}};
 vm.createContext(c);vm.runInContext(fs.readFileSync('public/js/hub-nakka-event.js','utf8'),c);
 await check.fire();assert.equal(calls.length,1);const review=host.children.find(n=>n.textContent==='REVIEW CREATE EVENT');await review.fire();assert.equal(calls[1].searchParams.get('page'),'nakkacreateprepare');
 const confirm=host.children.find(n=>n.textContent==='CREATE EVENT — TEST'),ack=host.children.find(n=>n.tag==='label').children[0];assert.equal(confirm.disabled,true);assert.equal(calls.length,2);ack.checked=true;ack.fire('change');const promise=confirm.fire();confirm.fire();await promise;
 assert.equal(calls.length,3);assert.equal(calls[2].searchParams.get('page'),'nakkacreateconfirm');assert.equal(calls[2].searchParams.get('confirmed'),'true');assert(host.children.some(n=>n.textContent==='Created once'));
});
